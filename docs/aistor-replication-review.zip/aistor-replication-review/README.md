# AIStor(S3) Bucket Replication 도입 검토 — 근거 정리 및 진행 확인 사항 (v2)

> 작성: 빅데이터 플랫폼 데이터 엔지니어링 · 최초 2026-09-29 · v2 피드백 반영
> 대상: AIStor(상용 MinIO) **Hot / Warm 2-Tier** 클러스터(이천) + 이천 dataops + 용인 dataops(신규) + Lake(Polaris)
> 선행 문서: [AIStor Hot/Warm + ILM/Replication 환경의 Iceberg-Spark 운영 가이드](../aistor-iceberg-ilm-guide/README.md)
> 진행 관리 표: [INDEX.md](./INDEX.md)

---

## 0. 한 장 요약 (순서: 담당자 확인 → Replication → ILM → 향후 구성)

| # | 분류 | 결론 | 근거 위치 |
|---|---|---|---|
| 0 | 선행 | **담당자 우려사항**(조회 케이스 · 복제 목적 · RPO · 운영 부담 · zip 필요성)을 먼저 확인하고 모드를 정한다 | [03-future/00](./03-future/00-owner-concerns.md) |
| 1 | Replication | Warm MinIO 데이터를 **HMS 로 조회하는 케이스가 없으면 실시간 Replication 은 불필요**. 모드 ① 조회용 / ② 백업용 / ③ 불필요 로 판단 | [02-evidence/01](./02-evidence/01-replication-necessity-backup.md) |
| 2 | Replication | 백업 용도(②)라면 **테이블 특성별 백업 시점**(merge·스냅샷 정리 후 복제)을 테스트로 정한다 (T-B1~T-B7) | [02-evidence/01 §3](./02-evidence/01-replication-necessity-backup.md) |
| 3 | Replication | S3 Replication(객체 단위 비동기) ≠ Iceberg 커밋(카탈로그 포인터 원자 교체) → 충돌 C1~C5 | [02-evidence/02](./02-evidence/02-iceberg-snapshot-vs-replication.md) |
| 4 | Replication · ILM | Scanner 가 복제 재큐잉(3회 실패 후) · Transition · 버전 정리를 함께 처리 → Scanner 가 느리면 함께 지연 | [02-evidence/03](./02-evidence/03-scanner-impact.md) |
| 5 | ILM | ILM 은 Transition · Expiration 뿐. 아카이브는 **A. zip 미사용 / B. 하이브리드(서비스 zip 변환 + ILM 이관) / C. 전면 Rollover** 중 **협의** | [02-evidence/04](./02-evidence/04-ilm-archive-options.md) |
| 6 | 아키텍처 | 이천 dataops ↔ AIStor: Private = ClusterMesh + BGP / Public = Ingress · L4 VIP | [01-architecture/01](./01-architecture/01-hot-warm-icheon-dataops.md) |
| 7 | 아키텍처 (모드 ①) | 용인은 Warm 만 조회 — Trino + HMS-Warm(Oracle), Lake 는 Polaris 가 HMS federation · Warm 은 **검증 후 등록** | [01-architecture/02](./01-architecture/02-warm-standalone-yongin.md), [03-future/02](./03-future/02-hms-oracle-split-todo.md) |
| 8 | 향후 (모드 ①) | 용인 → Warm 접근은 A. Public(VIP/Ingress) 경로 우선 | [03-future/01](./03-future/01-yongin-network-checklist.md) |

---

## 1. 문서 트리

```text
aistor-replication-review/
├── INDEX.md                                     요약 · 문서/그림 목록 · To-do · 일정 · 마일스톤 (표)
├── README.md                                    지금 문서 (요약 · 트리 · 보안 PDF · 전제/용어)
├── diagrams/                                    모든 그림 통합 (01~11 · .drawio/.gliffy/.svg)
├── 01-architecture/                             ── 1. 아키텍처 대응 장표
│   ├── 01-hot-warm-icheon-dataops.md            이천 Hot/Warm ↔ dataops (ClusterMesh·BGP·VIP·Ingress)
│   └── 02-warm-standalone-yongin.md             (모드 ①) 용인 Trino → HMS-Warm ← Polaris
├── 02-evidence/                                 ── 2. 근거 정리 (Replication → ILM 순)
│   ├── 01-replication-necessity-backup.md       복제 모드 판단 · 백업 시점 테스트
│   ├── 02-iceberg-snapshot-vs-replication.md    Iceberg vs Replication 충돌 C1~C5
│   ├── 03-scanner-impact.md                     Scanner 지연 영향 (복제 재큐잉 · Transition)
│   ├── 04-ilm-archive-options.md                ILM 한계 · 아카이브 A/B/C (협의)
│   ├── 05-internal-pdf-evidence-map.md          보안 PDF 확인 매핑 R-01~R-24
│   └── 06-official-reference-links.md           공개 공식 문서 링크 · 원문 인용
├── 03-future/                                   ── 3. 향후 구성 대응
│   ├── 00-owner-concerns.md                     담당자 우려 확인 (가장 먼저)
│   ├── 01-yongin-network-checklist.md           (조건부) 용인 → Warm 네트워크
│   ├── 02-hms-oracle-split-todo.md              (모드 ①) HMS(Oracle) 분리 To-do
│   └── 03-open-items-polaris-hot-warm-schema.md (모드 ①) Polaris · 스키마
└── tools/
    ├── diagram_lib.py                           draw.io / Gliffy / SVG 동시 생성 라이브러리
    └── gen_diagrams.py                          그림 스펙 (수정 후 재실행)
```

## 2. 그림 목록 (diagrams/ 통합)

| No | 그림 | 분류 | 사용 문서 |
|---|---|---|---|
| 01 | icheon-hot-warm-dataops | 아키텍처 | 01-architecture/01 |
| 02 | warm-standalone-yongin | 아키텍처 (모드 ①) | 01-architecture/02 |
| 03 | replication-mode-decision | Replication | 02-evidence/01, 03-future/00 |
| 04 | commit-unit-mismatch | Replication | 02-evidence/02, INDEX |
| 05 | iceberg-vs-replication-timeline | Replication | 02-evidence/02 |
| 06 | scanner-impact | Replication · ILM | 02-evidence/03 |
| 07 | ilm-archive-options | ILM | 02-evidence/04 |
| 08 | yongin-network-checkpoints | 향후 (조건부) | 03-future/01 |
| 09 | hot-warm-catalog-split | 향후 (모드 ①) | 03-future/02, 03 |
| 10 | verify-and-register | 향후 (모드 ①) | 03-future/02, INDEX |
| 11 | todo-milestones | 진행 관리 | INDEX |

| 파일 | 용도 | Confluence 반영 방법 |
|---|---|---|
| `*.gliffy` | Gliffy 네이티브 JSON (`application/gliffy+json` v1.3) | 페이지 편집 → **Gliffy Diagram** 매크로 → **Import** → 파일 업로드 |
| `*.drawio` | draw.io XML | **draw.io Diagram** 매크로 → *Import from* → Device, 또는 app.diagrams.net 에서 열기 |
| `*.svg` | 미리보기 (GitHub/IDE 렌더링용) | 이미지 첨부 용도. 아이콘은 단순 도형으로 표시됨 |

- 스타일: AWS 아키텍처 다이어그램 형식(흰 배경 · 얇은 컬러 그룹 박스 + 좌상단 배지 · 아이콘 하단 라벨 · 검정 직교 화살표).
- 색 규칙: **보라** k8s 클러스터 · **초록** 네트워크 · **레드** AIStor 스토리지 · **주황** Replication/백업 · **파랑** Lake · **빨강 박스** 확인·협의 필요 · **점선 박스** 조건부.
- 수정: `tools/gen_diagrams.py` 를 고친 뒤 `python3 tools/gen_diagrams.py` 로 11종 × 3포맷을 재생성합니다.

## 3. 사내 보안 PDF 목록 (본문 미인용 · 제목 기준 참조)

상세 매핑: [02-evidence/05-internal-pdf-evidence-map.md](./02-evidence/05-internal-pdf-evidence-map.md)

| ID | 문서명 | 주 용도 |
|---|---|---|
| **PDF-1** | [SK Hynix] AiStor 2-Tier 구성 시 고려사항.pdf | Hot/Warm 2-Tier 구성 방식·네트워크·접근 엔드포인트 권고 |
| **PDF-2** | Global Reference - Versioning, ILM, Replication, Object Locking_May2026.pdf | 4개 기능 간 상호작용(조합 제약) 매트릭스 |
| **PDF-3** | ILM (Information Lifecycle Management).pdf | Lifecycle 액션·필터·Scanner·Tier 동작 |
| **PDF-4** | Object Locking (Write On Read Merge).pdf | WORM/보존 정책, ILM·Replication 과의 제약 |
| **PDF-5** | Replication.pdf | 비동기/동기, 복제 대상, delete/delete-marker, resync, 시점 지정 복제 |
| **PDF-6** | Versioning.pdf | Versioning 필수 조건, delete marker, noncurrent 축적 |

## 4. 전제 및 용어

| 항목 | 이 문서의 전제 | 상태 |
|---|---|---|
| Hot / Warm 위치 | **둘 다 이천**, AIStor는 베어메탈 k8s 위에 구성 | 확정 |
| 이천 네트워크 | dataops ↔ AIStor: Cilium **ClusterMesh + BGP** (Private 대역) | 확정 |
| Public 노출 | **Ingress 주소** 또는 **LB VIP(스위치에 등록, 스위치가 로드밸런싱)** | 확정 |
| 용인 | Warm **접근만** (데이터 미보유) | 확정 |
| Lake 조회 | **Apache Polaris 가 HMS 를 federation** | 확정 |
| Replication 필요성 | Warm 을 HMS 로 조회하는 케이스 유무에 따라 모드 ①/②/③ | 🔍 담당자 확인 (OC-1, OC-2) |
| Replication 방향 | Hot → Warm **단방향**, Versioning ON | 🔍 가정 |
| RAW 아카이브 방식 | A / B / C 중 선택 — Rollover Job 은 확정 아님 | 🔍 협의 (AR-1) |
| Iceberg 테이블 버킷명 | Hot/Warm 동일 버킷명 유지 | 🔍 권고 ([02-evidence/02 §4](./02-evidence/02-iceberg-snapshot-vs-replication.md)) |

| 용어 | 의미 |
|---|---|
| Hot / Warm | AIStor 클러스터(티어) |
| 모드 ① / ② / ③ | 조회용 실시간 복제 / 백업용 복제 / 복제 불필요 ([근거 1](./02-evidence/01-replication-necessity-backup.md)) |
| 아카이브 A / B / C | zip 미사용 / 하이브리드(서비스 zip + ILM 이관) / 전면 Rollover ([근거 4](./02-evidence/04-ilm-archive-options.md)) |
| ILM Transition | Lifecycle 규칙으로 객체를 **Remote Tier**(Warm)로 이동. 조회는 Hot 엔드포인트 경유. 백업 효과 없음 |
| Bucket Replication | 버킷 단위 객체 **버전 복제**. Warm 에 **독립 조회 가능한 사본** |
| HMS-Hot / HMS-Warm | 이천 기존 Hive Metastore / 용인용 신규 Hive Metastore (Oracle 백엔드) |
| 🔍 · ⚠️ | 확인 필요 · 데이터 유실/서비스 영향 가능 |
